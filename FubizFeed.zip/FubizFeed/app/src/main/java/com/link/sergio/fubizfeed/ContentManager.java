package com.link.sergio.fubizfeed;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class ContentManager
{
    private static ContentManager mInstance;
    private        List<Article>  mArticlesList;

    private ContentManager()
    {

    }

    public static ContentManager getInstance()
    {
        if (mInstance == null)
            mInstance = new ContentManager();

        return mInstance;
    }

    public List<Article> getArticlesList(Context c)
    {
        if (mArticlesList == null)
        {
            mArticlesList = retrieveArticles(c);
        }
        return mArticlesList;
    }

    private static List<Article> retrieveArticles(Context context)
    {
        List<Article> articlesList = new ArrayList<>();
        String jsonString;
        try
        {
            InputStream is = context.getAssets().open("contenu.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            jsonString = new String(buffer, "UTF-8");
        }
        catch (IOException ex)
        {
            ex.printStackTrace();
            return articlesList;
        }

        try
        {
            JSONObject json = new JSONObject(jsonString);
            JSONArray articles = json.getJSONArray("items");
            int nbArticles = articles.length();
            for (int i = 0; i < nbArticles; i++)
            {
                articlesList.add(new Article(articles.getJSONObject(i)));
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }
        return articlesList;
    }


}
