package com.link.sergio.fubizfeed;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import com.squareup.picasso.Picasso;

/**
 * Created by sergio on 12/11/2015.
 */
public class ListAdapter extends BaseAdapter
{
    LayoutInflater mInflater;

    public ListAdapter(LayoutInflater inflater)
    {
        mInflater = inflater;
    }

    @Override
    public int getCount()
    {
        return 0;
    }

    @Override
    public Object getItem(int position)
    {
        return null;
    }

    @Override
    public long getItemId(int position)
    {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        //TODO: create cell
        View v = mInflater.inflate(R.layout.artilce_list_cell, null);


        Picasso.with(parent.getContext()).load("url").into(imageview);
        return new View(parent.getContext());
    }
}
