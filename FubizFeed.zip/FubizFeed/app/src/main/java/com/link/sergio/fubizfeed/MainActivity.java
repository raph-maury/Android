package com.link.sergio.fubizfeed;

import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.FrameLayout;

public class MainActivity extends AppCompatActivity implements ListFragment.OnItemClickedListener
{
    private boolean mTwoPanes = false;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FrameLayout detailContainer = (FrameLayout) findViewById(R.id.detail_container);
        if (detailContainer != null)
        {
            mTwoPanes = true;

            FragmentTransaction transaction = getFragmentManager().beginTransaction();
            transaction.add(R.id.detail_container, new DetailFragment());
            transaction.commit();
        }


    }

    @Override
    public void OnItemClicked(int position)
    {
        if (!mTwoPanes)
        {
            Intent intent = new Intent(this, DetailActivity.class);
            startActivity(intent);
        }
    }
}
