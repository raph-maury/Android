package com.link.sergio.fubizfeed;

import android.util.Log;
import org.json.JSONObject;

public class Article
{
    private String   id;
    private String   title;
    private String   url;
    private String   date;
    private String   author;
    private String   content;
    private String   thumbnail;
    private String   largeThumbnail;
    private String   summary;

    // attributs json
    public static final String ID                  = "id";
    public static final String TITLE               = "title";
    public static final String URL                 = "url";
    public static final String DATE                = "date";
    public static final String AUTHOR              = "author";
    public static final String CONTENT           = "content";
    public static final String THUMBNAIL         = "thumbnail";
    public static final String LARGETHUMBNAIL    = "largeThumbnail";
    public static final String SUMMARY           = "summary";

    public Article(JSONObject o)
    {
        try
        {
            this.id = o.optString(ID,null);
            this.title = o.isNull(TITLE) ? null : o.optString(TITLE, null);
            this.url = o.optString(URL, "");
            this.date = o.optString(DATE, null);
            this.author = o.optString(AUTHOR, "");
            this.content = o.optString(CONTENT, null);
            this.thumbnail = o.optString(THUMBNAIL, null);
            this.largeThumbnail = o.optString(LARGETHUMBNAIL, null);
            this.summary = o.optString(SUMMARY, null);
            if (this.summary != null)
                this.summary = this.summary.replaceAll("\\s+", " ");//remove white spaces from RSS sources
        }
        catch (Exception e)
        {
            Log.e("Article", "Error while parsing JSON", e);
        }
    }

    public String getId()
    {
        return id;
    }

    public String getTitle()
    {
        return title;
    }

    public String getUrl()
    {
        return url;
    }

    public String getDate()
    {
        return date;
    }

    public String getAuthor()
    {
        return author;
    }

    public String getLargeThumbnail()
    {
        return largeThumbnail;
    }

    public String getThumbnail()
    {
        return thumbnail;
    }

    public String getContent()
    {
        return content;
    }

    public String getSummary()
    {
        return summary;
    }
}
